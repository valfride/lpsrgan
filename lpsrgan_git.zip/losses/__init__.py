from .losses import register, make
from . import lossPack
# from . import MSE
# from . import OcrFeatureLoss