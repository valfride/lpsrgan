from .models import register, make
from . import rdn
from . import rdn_SU
from . import ocr_rodosol
from . import dcdpa
from . import srefpn
from . import cgnet
from . import diffrdn
from . import mprnet
from . import cgnetV2
from . import RDN3D
from . import cgnetV3
from . import cgnet_deformable2d_arch_refinement
#new architectures as baselines SR
from . import edsr_arch
from . import ecbsr_arch
from . import duf_arch
from . import cgnet_deformable2d_arch
from . import LSTM_SR_arch
from . import sibgrapi2022
from . import multi_img_net
from . import lpsrgan_arch
#new architectures as baselines OCR
from . import GP_LPR_arch

