import torch
import torch.nn as nn
import torch.nn.functional as F
from argparse import Namespace
from models import register
import math

# from torchviz import make_dot
import torchvision



class Im2Seq(nn.Module):
    def __init__(self, in_channels, out_channels, ks_size=1, padding="same"):
        super(Im2Seq, self).__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_channels=in_channels, out_channels=out_channels, kernel_size=ks_size, stride=ks_size, padding="same"),
            nn.ReLU()
        )
        
    def forward(self, x):
        # Apply block
        x = self.block(x)
        
        # Reshape the output to (batch, sequence_length, feature_size)
        batch_size, channels, height, width = x.size() # Rearrange to (batch_size, height, width, channels)
        x = x.permute(0, 2, 3, 1). contiguous()        # Flatten the spatial dimensions to form the sequence
        x = x.view(batch_size, -1, channels)
        
        return x
        
class MultiheadAttention(nn.Module):
    def __init__(self, img_channels, output_size, embed_size=128, num_heads=16):
        super(MultiheadAttention, self).__init__()
        self.embedding = nn.Linear(img_channels, embed_size)
        self.multihead_attention = nn.MultiheadAttention(embed_size, num_heads)
        self.fc = nn.Linear(embed_size, output_size)

    def forward(self, x):
        B, C, H, W = x.shape
        x = x.permute(0, 2, 3, 1)  # Rearrange to (B, H, W, C)
        x = x.view(B, H * W, C)  # Flatten to (B, H*W, C)
        
        embeddings = self.embedding(x)  # Project to embedding space (B, H*W, embed_size)
        embeddings = embeddings.permute(1, 0, 2)  # Permute to (H*W, B, embed_size) for MultiheadAttention
        
        attention_output, _ = self.multihead_attention(embeddings, embeddings, embeddings)
        
        attention_output = attention_output.permute(1, 0, 2)  # Permute back to (B, H*W, embed_size)
        output = self.fc(attention_output).view(B, H, W, -1).permute(0, 3, 1, 2)  # Reshape to image shape
        
        return output

class lstm_attention(nn.Module):
    def __init__(self, input_size, hidden_size, num_layers, output_size, image_shape, bidirectional=True, learn_initial_state=True):
        super(lstm_attention, self).__init__()
        self.num_layers = num_layers
        self.hidden_size = hidden_size
        self.num_directions = 2 if bidirectional else 1
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, bidirectional=bidirectional, batch_first=True)
        
        self.fc = nn.Linear(hidden_size * self.num_directions, hidden_size * self.num_directions)
        self.attention = nn.Linear(hidden_size * self.num_directions, hidden_size * self.num_directions)
        
        
        if learn_initial_state:
            self.h_0 = nn.Parameter(torch.zeros(num_layers* self.num_directions, 1, hidden_size))
            self.c_0 = nn.Parameter(torch.zeros(num_layers* self.num_directions, 1, hidden_size))
        else:
            self.h_0 = None
            self.c_0 = None

    def reset_states(self, batch_size, device):
        # Initialize initial states (either learnable or fixed to zeros)
        if self.h_0 is None or self.c_0 is None:
            h_0 = torch.zeros(self.num_layers * self.num_directions, batch_size, self.hidden_size).to(device)
            c_0 = torch.zeros(self.num_layers * self.num_directions, batch_size, self.hidden_size).to(device)
        else:
            h_0 = self.h_0.repeat(1, batch_size, 1).to(device)
            c_0 = self.c_0.repeat(1, batch_size, 1).to(device)
        return h_0, c_0
        
    def forward(self, features):
        batch_size, num_channels, height, width = features.size()
        features = features.view(batch_size, -1, num_channels)
        
        h_0, c_0 = self.reset_states(batch_size, features.device)
        
        lstm_out, (h_0, c_0) = self.lstm(features, (h_0, c_0))
        
        # Concatenate forward and backward hidden states if bidirectional
        if self.num_directions > 1:
            lstm_out = lstm_out.view(batch_size, -1, self.num_directions, self.hidden_size)
            lstm_out = torch.cat((lstm_out[:, :, 0, :], lstm_out[:, :, 1, :]), dim=-1)

        attention_logits = self.attention(lstm_out)
        
        attention_logits = attention_logits.squeeze(-1)
        attention_weights = torch.softmax(attention_logits, dim=1)
        context_vector = torch.sum(attention_weights * lstm_out, dim=1)
        context_vector_expanded = context_vector.unsqueeze(1).expand(-1, attention_logits.size(1), -1)  # Shape: (batch_size, seq_len, hidden_size * num_directions)
        combined_matrix = attention_logits * context_vector_expanded  # Shape: (batch_size, seq_len, hidden_size * num_directions)
        # combined_matrix = combined_matrix.sum(dim=-1)  # Shape: (batch_size, seq_len)

        # attention_logits = self.attention(lstm_out)
        # attention_weights = F.softmax(attention_logits, dim=1)
        # context_vector = torch.sum(attention_weights * lstm_out, dim=1)
        # output = self.fc(context_vector)
        # return output, attention_logits
        return combined_matrix

class DeformableConvLayer(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, stride=1):
        super(DeformableConvLayer, self).__init__()
        self.padding = padding = math.ceil((kernel_size - 1) / 2)  # Calculate "same" padding for stride 1
        self.stride = stride
        self.conv_offset_mask = nn.Conv2d(in_channels, 3 * kernel_size * kernel_size, kernel_size=kernel_size, stride=stride, padding=padding)
        self.weight = nn.Parameter(torch.Tensor(out_channels, in_channels, kernel_size, kernel_size))
        self.bias = nn.Parameter(torch.Tensor(out_channels))
        
        self._init_weight()
        
    def _init_weight(self):
        nn.init.constant_(self.conv_offset_mask.weight, 0.)
        nn.init.constant_(self.conv_offset_mask.bias, 0.)
        nn.init.kaiming_uniform_(self.weight, a=math.sqrt(5))
        fan_in, _ = nn.init._calculate_fan_in_and_fan_out(self.weight)
        bound = 1 / math.sqrt(fan_in)
        nn.init.uniform_(self.bias, -bound, bound)

    def forward(self, x):
        out = self.conv_offset_mask(x)
        o1, o2, mask = torch.chunk(out, 3, dim=1)
        offset = torch.cat((o1, o2), dim=1)
        mask = torch.sigmoid(mask)
        
        x = torchvision.ops.deform_conv2d(input=x, 
                        offset=offset, 
                        weight=self.weight, 
                        bias=self.bias, 
                        padding=self.padding,
                        mask=mask,
                        stride=self.stride)
        
        return x

class ResidualDenseBlock(nn.Module):
    def __init__(self, in_channels, growth_rate, num_layers, img_input_shape, use_deformable_conv=False):
        super(ResidualDenseBlock, self).__init__()
        self.layers = nn.ModuleList()
        self.growth_rate = growth_rate
        self.in_channels = in_channels
        self.use_deformable_conv = use_deformable_conv
        
        for i in range(num_layers):
            if use_deformable_conv and i == num_layers - 1:
                # Last layer uses deformable convolution
                self.layers.append(DeformableConvLayer(in_channels + i * growth_rate, growth_rate, kernel_size=3))
            else:
                self.layers.append(nn.Conv2d(in_channels + i * growth_rate, growth_rate, kernel_size=3, padding="same"))

        
        self.local_feature_fusion = nn.Conv2d(
            in_channels + num_layers * growth_rate,
            growth_rate,
            kernel_size=1,
            stride=1,
            padding=0
        )
               
    def forward(self, x):
        features = [x]
        
        for layer in self.layers:
            out = layer(torch.cat(features, 1))
            out = torch.relu(out)
            features.append(out)
            
        out = torch.cat(features, 1)   
        out = self.local_feature_fusion(out)
        
        return out

class Conv3dSame(nn.Conv3d):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding=0, dilation=1, groups=1, bias=True):
        super(Conv3dSame, self).__init__(in_channels, out_channels, kernel_size, stride, padding, dilation, groups, bias)
        # Compute the necessary padding
        self.padding = self.calculate_padding(kernel_size, stride, dilation)

    def calculate_padding(self, kernel_size, stride, dilation):
        if isinstance(kernel_size, int):
            kernel_size = (kernel_size, kernel_size, kernel_size)
        if isinstance(stride, int):
            stride = (stride, stride, stride)
        if isinstance(dilation, int):
            dilation = (dilation, dilation, dilation)
        
        # Calculate padding for each dimension
        padding = []
        for k, s, d in zip(kernel_size, stride, dilation):
            p = ((d * (k - 1) + 1 - s) + 1) // 2
            padding.append(p)
        return tuple(padding)    

class RDN(nn.Module):
    def __init__(self, args):
        super(RDN, self).__init__()
        
        self.rdb_blocks = nn.ModuleList()
        self.bidirectional = True
        self.convlstm_00 = ConvLSTMLayer(3, 32, kernel_size=3, num_layers=6, batch_first=True, squeeze_outputs=False, bidirectional=self.bidirectional)
        self.conv1 = nn.Conv2d(args.in_channels*6*64, args.growth_rate, kernel_size=3, stride=1, padding=1)
        
        for _ in range(args.num_blocks):
            self.rdb_blocks.append(ResidualDenseBlock(args.growth_rate, args.growth_rate, args.num_layers, args.img_input_shape, use_deformable_conv=args.use_deformable_conv))
                    
        
        self.global_conv = nn.Conv2d(args.growth_rate * args.num_blocks, args.growth_rate, kernel_size=3, stride=1, padding=1)
       
        self.Block_3D_00 = nn.Sequential(
            Conv3dSame(args.growth_rate, 64, 3),
            Conv3dSame(64, 3, 3),
            nn.ReLU(),
            )
        
        self.convlstm_01 = ConvLSTMLayer(1, 32, kernel_size=3, num_layers=5, batch_first=True, squeeze_outputs=False, bidirectional=self.bidirectional)
        
        
        self.Block_3D_01 = nn.Sequential(
            Conv3dSame(3 * 5, 64, 3),
            Conv3dSame(64, 32, 3),
            nn.ReLU(),
            )
        #upscale module
        
        self.upscale = []
        for _ in range(2 // 2):
            self.upscale.extend([
                nn.Conv2d(2*1024, args.growth_rate*2**2, kernel_size=3, stride=1, padding='same', bias=True),
                nn.PixelShuffle(2)
                ])
        self.conv_out = nn.Conv2d(args.in_channels*3, 3, kernel_size=3, stride=1, padding='same', bias=True)
        self.upscale = nn.Sequential(*self.upscale)
        self.output = nn.Conv2d(args.growth_rate, args.out_channels, kernel_size=3, stride=1, padding='same', bias=True)
        
        
    def forward(self, x):
        x_in = x
        # x_in = x.unsqueeze(2)
        x_in, _, _ = self.convlstm_00(x_in)
        
        if self.convlstm_00.batch_first:
            x_in = x_in.permute(1, 2, 0, 3, 4, 5)  # (batch_size, seq_len, layer, num_channels, height, width) -> (batch_size, num_channels, seq_len, height, width)
        else:
            x_in = x_in.permute(2, 1, 0, 3, 4, 5)

        x_in = x_in.reshape(x_in.size(0), -1, x_in.size(4), x_in.size(5))
        out = torch.relu(self.conv1(x_in))
        
        local_features = []

        for rdb in self.rdb_blocks:
            out = rdb(out)
            local_features.append(out)

        out = torch.cat(local_features, 1)
        out = self.global_conv(out)
        out = out.unsqueeze(2)
        out = self.Block_3D_00(out)
        out, _, _ = self.convlstm_01(out)
        
        if self.convlstm_01.batch_first:
            out = out.permute(1, 2, 0, 3, 4, 5)  # (batch_size, seq_len, layer, num_channels, height, width) -> (batch_size, num_channels, seq_len, height, width)
        else:
            out = out.permute(2, 1, 0, 3, 4, 5) 
        
        out = out.reshape(out.size(0), -1, out.size(3), out.size(4), out.size(5))
        
        out = self.Block_3D_01(out)
        out = out.view(out.size(0), -1,out.size(3), out.size(4))
        out = self.output(self.upscale(out))
        x = x.view(x.size(0), -1,x.size(3), x.size(4))
        x = torch.relu(self.conv_out(x))
        out = torch.sigmoid(out + F.interpolate(x, (out.size(2), out.size(3)), mode='nearest'))
        
        return out


@register('lstm_sr_arch')       
def lstm_sr_arch(in_channels=5, out_channels=3, growth_rate=128, num_blocks=8, num_layers=3, img_input_shape=(3, 16, 48), use_deformable_conv=True):
    args = Namespace()
    args.in_channels = in_channels
    args.out_channels = out_channels
    args.growth_rate = growth_rate
    args.num_blocks = num_blocks
    args.num_layers = num_layers
    args.img_input_shape = img_input_shape
    args.use_deformable_conv = use_deformable_conv
    
    return RDN(args)

if __name__ == '__main__':
    from ConvLstm import ConvLSTMLayer

    feature_maps = torch.rand(2, 5, 3, 16, 48)
    l = Im2Seq(3,3)  
   
    rdn = lstm_sr_arch()
    
    output = rdn(feature_maps)
    print(output.shape)
else:
    from .ConvLstm import ConvLSTMLayer