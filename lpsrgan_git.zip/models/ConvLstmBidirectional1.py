import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvLSTMCell(nn.Module):
    def __init__(self, in_channels, hidden_channels, kernel_size, bias=True):
        super(ConvLSTMCell, self).__init__()
        
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2
        self.bias = bias
        
        # Defined gates: forget, input, cell state, output
        self.Wxi = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whi = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxf = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whf = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxc = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whc = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxo = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Who = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
    def forward(self, x, h, C):
        i = torch.sigmoid(self.Wxi(x) + self.Whi(h))
        f = torch.sigmoid(self.Wxf(x) + self.Whf(h))
        g = torch.tanh(self.Wxc(x) + self.Whc(h))
        o = torch.sigmoid(self.Wxo(x) + self.Who(h))
        
        C = f * C + i * g
        h = o * torch.tanh(C)
        
        return h, C
    
class ConvLSTMLayer(nn.Module):
    def __init__(self, input_channels, hidden_channels, kernel_size, num_layers, bidirectional=True, batch_first=False, squeeze_outputs=True):
        super(ConvLSTMLayer, self).__init__()
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.squeeze = squeeze_outputs
        
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1

        # Create a list of ConvLSTM cells for each layer
        self.cells = nn.ModuleList([
            ConvLSTMCell(input_channels if i == 0 else hidden_channels * self.num_directions, hidden_channels, kernel_size)
            for i in range(num_layers)
        ])
    
    
    def _split_directions(self, states, batch_size, dim=0):
       # Split hidden states for forward and backward directions
       return torch.split(states, batch_size, dim)
   
    
   
    def forward(self, x, hidden=None):
        if self.batch_first:
            batch_size, seq_len, num_channels, height, width = x.size()
        else:
            seq_len, batch_size, num_channels, height, width = x.size()
        
        if hidden is None:
            if not self.batch_first:
                h_0 = torch.zeros(self.num_layers, batch_size, self.hidden_channels * self.num_directions, height, width).to(x.device)
                C_0 = torch.zeros(self.num_layers, batch_size, self.hidden_channels * self.num_directions, height, width).to(x.device)
            else:
                h_0 = torch.zeros(batch_size, self.num_layers , self.hidden_channels * self.num_directions, height, width).to(x.device)
                C_0 = torch.zeros(batch_size, self.num_layers , self.hidden_channels * self.num_directions, height, width).to(x.device)
            
        else:
           h_0, C_0 = hidden
        
        outputs = []
        h_n, C_n = [], []
        
        for layer in range(self.num_layers):
            if self.batch_first:
                h_t, C_t = h_0[:, layer, :, :, :], C_0[:, layer, :, :, :]
            else:
                h_t, C_t = h_0[layer], C_0[layer]
            output_seq = []
            # print(layer)
            for t in range(seq_len):
                x_t = x[:, t, :, :, :] if self.batch_first else x[t, :, :, :, :]
       
                if self.bidirectional:
                    
                    h_t_f, h_t_b = self._split_directions(h_t, self.hidden_channels, dim=1)
                    # print(h_t_f.shape)
                    C_t_f, C_t_b = self._split_directions(C_t, self.hidden_channels, dim=1)
                    
                    
                    h_t_f, C_t_f = self.cells[layer](x_t, h_t_f[0], C_t_f[0])
                    h_t_b, C_t_b = self.cells[layer](x_t.flip(dims=[0]), h_t_b[0], C_t_b[0])
       
                    h_t = torch.cat([h_t_f, h_t_b], dim=1)
                    C_t = torch.cat([C_t_f, C_t_b], dim=1)
                    output_seq.append(h_t)
                else:
                    h_t, C_t = self.cells[layer](x_t, h_t[0], C_t[0])
                    output_seq.append(h_t)
        
            x = torch.stack(output_seq, dim=1 if self.batch_first else 0)
            outputs.append(x)
            h_n.append(h_t)
            C_n.append(C_t)
        
        
        outputs = torch.cat(outputs, dim=1)
        h_n = torch.cat(h_n, dim=1)
        C_n = torch.cat(C_n, dim=1)
        
        if self.squeeze:
            def squeeze_outputs(outputs):
                outputs = outputs.squeeze(2)
                return outputs
            outputs = squeeze_outputs(outputs)

        return outputs, h_n, C_n
# class ConvLSTMLayer(nn.Module):
#     def __init__(self, input_channels, hidden_channels, kernel_size, num_layers, batch_first=False, squeeze_outputs=True):
#         super(ConvLSTMLayer, self).__init__()
#         self.hidden_channels = hidden_channels
#         self.num_layers = num_layers
#         self.batch_first = batch_first
#         self.squeeze = squeeze_outputs       

#         # Create a list of ConvLSTM cells for each layer
#         self.cells = nn.ModuleList([ConvLSTMCell(input_channels if i == 0 else hidden_channels, hidden_channels, kernel_size) for i in range(num_layers)])

#     def forward(self, x, hidden=None):
#         if self.batch_first:
#             batch_size, seq_len, num_channels, height, width = x.size()
#         else:
#             seq_len, batch_size, num_channels, height, width = x.size()

#         if hidden is None:
#             # Initialize hidden states and cell states to zeros
#             h_0 = [torch.zeros(batch_size, self.hidden_channels, height, width).to(x.device) for _ in range(self.num_layers)]
#             C_0 = [torch.zeros(batch_size, self.hidden_channels, height, width).to(x.device) for _ in range(self.num_layers)]
#         else:
#             h_0, C_0 = hidden
        
#         outputs = []
#         h_n, C_n = [], []

#         for layer in range(self.num_layers):
#             h_t, C_t = h_0[layer], C_0[layer]
#             output_seq = []

#             for t in range(seq_len):
#                 x_t = x[:, t, :, :, :] if self.batch_first else x[t, :, :, :, :]
#                 h_t, C_t = self.cells[layer](x_t, h_t, C_t)
#                 output_seq.append(h_t)

#             x = torch.stack(output_seq, dim=1 if self.batch_first else 0)
#             outputs.append(x)
#             h_n.append(h_t)
#             C_n.append(C_t)

#         outputs = torch.stack(outputs, dim=0)
#         h_n = torch.stack(h_n, dim=0)
#         C_n = torch.stack(C_n, dim=0)
        
#         if self.squeeze is True:
#             def squeeze_outputs(outputs):
#                 outputs = outputs.squeeze(2)
#                 return outputs
#             outputs = squeeze_outputs(outputs)

#         return outputs, h_n, C_n
    
if __name__ == '__main__':
    feature_maps = torch.rand(3, 3, 16, 48)
    image = feature_maps.unsqueeze(2)
    print(image.shape)
    # image = image.permute(0, 2, 1, 3, 4)
    # print(image.shape)
    lstm = ConvLSTMLayer(input_channels=1, hidden_channels=32, kernel_size=3, num_layers=3, batch_first=True, bidirectional=False)
    print(lstm)
    outputs, h, c = lstm(image)
    outputs = outputs.squeeze(2)

    print(image.shape)
    print(f"H:{h.shape}\nC:{c.shape}\nO:{outputs.shape}")