import torch
import torch.nn as nn
import numpy as np

from argparse import Namespace
from models import register

class SU(nn.Module):
    def __init__(self, channels):
        super(SU, self).__init__()
        self.SU = nn.Sequential(
            nn.ReLU(),
            nn.Conv3d(channels, channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.Sigmoid()
            )
        
    def forward(self, x):
        return x*self.SU(x)

class DWConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding='same', bias=False):
        super(DWConv2d, self).__init__()

        self.dConv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=1, groups=in_channels, padding=padding, bias=bias),
            nn.Conv2d(in_channels, out_channels, kernel_size=1)
            )
        
    def forward(self, x):
        x = self.dConv(x)
        
        return x

class RDB_layer(nn.Module):
    def __init__(self, in_channels, grow_rate, k_size=3):
        super(RDB_layer, self).__init__()
        self.in_channels = in_channels
        self.grow_rate = grow_rate
        self.k_size = k_size
        
        self.SU = SU(grow_rate)
        
        self.conv=nn.Sequential(*[
            nn.Conv3d(self.in_channels, self.grow_rate, kernel_size=self.k_size, padding=(self.k_size-1)//2, stride=1),
            self.SU
            # nn.ReLU()
            ])
        
        
        
    def forward(self, x):
        return torch.cat((x, self.conv(x)), dim=1)
    
class RDB(nn.Module):
    def __init__(self, init_grow_rate, grow_rate, n_conv, k_size):
        super(RDB, self).__init__()
        self.grow_init = init_grow_rate
        self.grow_rate = grow_rate
        self.n = n_conv
        convs = []
        
        for c in range(self.n):
            convs.append(RDB_layer(self.grow_init+c*self.grow_rate, self.grow_rate))
        
        self.convs=nn.Sequential(*convs)
        self.LFF = nn.Conv3d(self.grow_init+self.grow_rate*self.n, self.grow_init, kernel_size=1, padding=0, stride=1)
        
    def forward(self, x):        
        return self.LFF(self.convs(x))+x
    
class DenseLayer(nn.Module):
    def __init__(self, in_channels, out_channels, bias=False):
        super(DenseLayer, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding="same", bias=bias)
        self.ReLU = SU(out_channels)
        
        
    def forward(self, x):
        return torch.cat([x, self.ReLU(self.conv(x))], 1)    
    

class RDN(nn.Module):
    def __init__(self, args):
        super(RDN, self).__init__()
        self.args=args
        self.scale = args.scale
        self.depth_size = args.depth
        self.kernel = args.kernel
        
        self.blocks, self.conv_layers, self.out_channels = {
            'A' : (20, 6, 32),
            'B' : (16, 8, 64),
            'C' : (20, 10, 128)
            }[args.RDNconfig]
        
        self.SFE1 = nn.Conv3d(self.depth_size, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        self.SFE2 = nn.Conv3d(args.init_grow_rate, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
        self.RDBs = nn.ModuleList()
        
        for i in range(self.blocks):
            self.RDBs.append(
                RDB(init_grow_rate=args.init_grow_rate, grow_rate=self.out_channels, n_conv=self.conv_layers, k_size=args.kernel),
                )
            
        self.GFF = nn.Sequential(*[
            nn.Conv3d(self.blocks*args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1),
            nn.Conv3d(args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1)
            ])
        self.outConv = nn.Conv3d(args.init_grow_rate, self.depth_size, self.kernel, padding='same')
        self.UPNet = nn.Sequential(*[
                    nn.Conv2d(self.depth_size*3, self.out_channels * self.scale * self.scale, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    nn.PixelShuffle(self.scale),
                    nn.Conv2d(self.out_channels, 3, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    # nn.Tanh()                
                ])
        
    def forward(self, x):
        b, c, h, w = x.shape
        x = x.view(b, self.depth_size, (c//self.depth_size), h, w)
        f1 = self.SFE1(x)
        x = self.SFE2(f1)
        
        RDBs_out = []
        
        for i in range(self.blocks):
            x = self.RDBs[i](x)
            RDBs_out.append(x)
            
        x = self.GFF(torch.cat(RDBs_out,1))
        x += f1
        x = self.outConv(x)
        x = x.view(b, c, h, w)
        
        return self.UPNet(x)

def compute_num_params(model, text=False):
    tot = int(sum([np.prod(p.shape) for p in model.parameters()]))
    if text:
        if tot >= 1e6:
            return '{:.1f}M'.format(tot / 1e6)
        else:
            return '{:.1f}K'.format(tot / 1e3)
    else:
        return tot    

@register('RDN3D')       
def RDN3D(in_channels=15, depth=5, scale=4, kernel=3, RDNconfig='B', init_grow_rate=128):
    args = Namespace()
    args.in_channels = in_channels
    args.depth = depth
    args.scale = scale
    args.kernel = kernel
    args.RDNconfig = RDNconfig
    args.init_grow_rate = init_grow_rate
    
    return RDN(args)

if __name__ == '__main__':
    # Assuming input data with shape (batch_size, depth, channels, height, width)
    input_data = torch.randn((16, 15, 20, 40))
    input_data2 = torch.randn((64, 32, 20, 40))
    # Net = RDN(num_channels=15, num_features=128, growth_rate=128, num_blocks=32, num_layers=3, bias=False)
    Net = RDN3D()
    
    print(Net)
    print(compute_num_params(Net, text=True))
    # def forward(self, x):
    #     # x shape: (batch_size, depth, channels, height, width)
        
    #     b, c, h, w = x.shape
    #     x = x.unsqueeze(1).expand(b, self.depth_size, -1, h, w)
    #     x = self.conv1(x)
    #     x = self.RDN(x)
    #     x = x.view(self.batch_size, -1, x.shape[3], x.shape[4])
    #     x = nn.Conv2d(x.shape[1], 32, kernel_size=1, stride=1, padding="same", bias=False).cuda()(x)
    #     PS1 = self.upscale(x)
    #     output = self.Output(PS1)
        
    #     return output
    # output = DWConv3d(15, 32, 3)(input_data)
    # rdn = RDB(in_channels=15, out_channels=32, growth_rate=3)
    # Create an instance of the network
    # net = Simple3DNet()
    
    # Forward pass
    # output = net(input_data2)
    
    # Print the shape of the output
    print("Output shape:", Net(input_data).shape)
