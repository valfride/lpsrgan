import torch
import torch.nn as nn

from argparse import Namespace
from models import register

class SU(nn.Module):
    def __init__(self, channels):
        super(SU, self).__init__()
        self.SU = nn.Sequential(
            nn.ReLU(),
            nn.Conv2d(channels, channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.Sigmoid()
            )
        
    def forward(self, x):
        return x*self.SU(x)

class Eigen_weight(nn.Module):
    def __init__(self, input_dim):
        super(Eigen_weight, self).__init__()
        self.Conv2d_in = nn.Conv2d(input_dim, input_dim, kernel_size=1, stride=1, padding=0, bias=False)
        self.softmax = nn.Softmax(dim=1)
        
    def calculate_eigenvalues_and_vectors(self, patches):
        # Compute eigenvalues and eigenvectors for each patch
        batch_size, num_channels, _, _ = patches.size()
        eigenvalues_list = []
        eigenvectors_list = []
        
        for i in range(batch_size):
            patch = patches[i].view(num_channels, -1)  # Flatten the patch
            cov_matrix = torch.mm(patch, patch.t())
            eigenvalues, eigenvectors = torch.linalg.eig(cov_matrix)
            eigenvalues_list.append(eigenvalues)
            eigenvectors_list.append(eigenvectors)
        
        return torch.stack(eigenvalues_list), torch.stack(eigenvectors_list)
    
    def forward(self, patches):
        # Compute eigenvalues and eigenvectors
        eigenvalues, _ = self.calculate_eigenvalues_and_vectors(patches)
        eigenvalues = eigenvalues.abs()
        
        # Apply the convolutional layer to compute attention weights
        attention_weights = self.Conv2d_in(eigenvalues.unsqueeze(2).unsqueeze(3))
        
        # Apply softmax to normalize the attention weights along the spatial dimensions
        attention_weights = self.softmax(attention_weights)
        
        # Multiply the original eigenvalues by the attention weights
        weighted_eigenvalues = eigenvalues.unsqueeze(2).unsqueeze(3) * attention_weights
        
        # Sum along the spatial dimensions to get the final weighted eigenvalues
        weighted_eigenvalues = weighted_eigenvalues.sum(dim=(2, 3))
        
        return weighted_eigenvalues.unsqueeze(2).unsqueeze(3) * patches

class RDB_layer(nn.Module):
    def __init__(self, in_channels, grow_rate, k_size=3):
        super(RDB_layer, self).__init__()
        self.in_channels = in_channels
        self.grow_rate = grow_rate
        self.k_size = k_size
        
        self.SU = SU(grow_rate)
        
        self.conv=nn.Sequential(*[
            nn.Conv2d(self.in_channels, self.grow_rate, kernel_size=self.k_size, padding=(self.k_size-1)//2, stride=1),
            self.SU
            # nn.ReLU()
            ])
        
        
        
    def forward(self, x):
        return torch.cat((x, self.conv(x)), dim=1)
        
class RDB(nn.Module):
    def __init__(self, init_grow_rate, grow_rate, n_conv, k_size):
        super(RDB, self).__init__()
        self.grow_init = init_grow_rate
        self.grow_rate = grow_rate
        self.n = n_conv
        self.Eigen_weight = Eigen_weight(init_grow_rate)
        convs = []
        
        for c in range(self.n):
            convs.append(RDB_layer(self.grow_init+c*self.grow_rate, self.grow_rate))
        
        self.convs=nn.Sequential(*convs)
        self.LFF = nn.Conv2d(self.grow_init+self.grow_rate*self.n, self.grow_init, kernel_size=1, padding=0, stride=1)
        
    def forward(self, x):        
        return self.LFF(self.convs(x))*self.Eigen_weight(x) + x #self.LFF(self.convs(x))+x ==>old version
        
class RDN(nn.Module):
    def __init__(self, args):
        super(RDN, self).__init__()
        self.args=args
        self.scale = args.scale
        
        self.kernel = args.kernel
        
        self.blocks, self.conv_layers, self.out_channels = {
            'A' : (20, 6, 32),
            'B' : (16, 8, 64),
            'C' : (20, 10, 128)
            }[args.RDNconfig]
        
        self.SFE1 = nn.Conv2d(args.in_channels, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        self.SFE2 = nn.Conv2d(args.init_grow_rate, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
        self.RDBs = nn.ModuleList()
        
        for i in range(self.blocks):
            self.RDBs.append(
                RDB(init_grow_rate=args.init_grow_rate, grow_rate=self.out_channels, n_conv=self.conv_layers, k_size=args.kernel),
                )
            
        self.GFF = nn.Sequential(*[
            nn.Conv2d(self.blocks*args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1),
            nn.Conv2d(args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1)
            ])
        
        self.UPNet = nn.Sequential(*[
                    nn.Conv2d(args.init_grow_rate, self.out_channels * self.scale * self.scale, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    nn.PixelShuffle(self.scale),
                    nn.Conv2d(self.out_channels, args.in_channels, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    # nn.Tanh()                
                ])
        
    def forward(self, x):
        f1 = self.SFE1(x)
        x = self.SFE2(f1)
        
        RDBs_out = []
        
        for i in range(self.blocks):
            x = self.RDBs[i](x)
            RDBs_out.append(x)
            
        x = self.GFF(torch.cat(RDBs_out,1))
        x += f1
        
        return self.UPNet(x)
        
@register('rdn_su')        
def make_rdn_su(init_grow_rate=64, kernel=3, scale=4, RDNconfig='C'):
    args = Namespace()
    args.init_grow_rate = init_grow_rate
    args.kernel = kernel
    args.RDNconfig = RDNconfig
    
    args.scale = scale
    args.in_channels = 3
    
    return RDN(args)

if __name__ == '__main__':
   model =  make_rdn_su()
   feature_maps = torch.rand(3, 3, 41, 20)
   # print(compute_num_params(model))
   print(model(feature_maps).shape)
