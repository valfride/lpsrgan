import torch
import torch.nn as nn
import torch.nn.functional as F

from argparse import Namespace
from models import register

class BasicBlock(nn.Module):
    """Basic Block"""

    expansion = 1


    def __init__(self, in_channels, out_channels, stride=1):
        super().__init__()

        #residual block
        self.residual_function = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=stride, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels, kernel_size=3, stride=stride, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(out_channels, out_channels * BasicBlock.expansion, kernel_size=3, padding=1),
        )

        #shortcut
        self.shortcut = nn.Sequential()

    def forward(self, x):
        return self.residual_function(x) + self.shortcut(x)


class SREFPN(nn.Module):

    def __init__(self, args):
        super().__init__()
        
        self.block = args.basicBlock
        self.num_block = args.num_block
        self.in_channels = args.in_channels
        self.up_scale = args.up_scale
        
        out_channels = 3

        #BackBone Blocks
        self.conv1 = nn.Sequential(nn.Conv2d(3, self.in_channels, kernel_size=3, padding=1))
        self.conv2_x = self._make_layer(self.block, self.in_channels, self.num_block[0], 1)# num_block=2#
        self.conv3_x = self._make_layer(self.block, self.in_channels, self.num_block[1], 1)
        self.conv4_x = self._make_layer(self.block, self.in_channels, self.num_block[2], 1)
        self.conv5_x = self._make_layer(self.block, self.in_channels, self.num_block[3], 1)
        self.conv6_x = self._make_layer(self.block, self.in_channels, self.num_block[4], 1)

        #Reconstruction Network
        self.mainconv1 = nn.Conv2d(67, out_channels * (self.up_scale ** 2), (3, 3), (1, 1), (1, 1)) #pixel shuffle
        self.pixel_shuffle = nn.PixelShuffle(self.up_scale)

        # Top layer
        self.toplayer = nn.Conv2d(self.in_channels, 64, kernel_size=1, stride=1, padding=0)

        # Smooth layers
        self.smooth1 = nn.Conv2d(64, 64, kernel_size=1, stride=1, padding=0)
        self.smooth2 = nn.Conv2d(64, 64, kernel_size=1, stride=1, padding=0)
        self.smooth3 = nn.Conv2d(64, 64, kernel_size=1, stride=1, padding=0)
        self.smooth4 = nn.Conv2d(64, 64, kernel_size=1, stride=1, padding=0)

        # Lateral layers
        self.latlayer1 = nn.Conv2d(self.in_channels, 64, kernel_size=1, stride=1, padding=0)
        self.latlayer2 = nn.Conv2d(self.in_channels, 64, kernel_size=1, stride=1, padding=0)
        self.latlayer3 = nn.Conv2d(self.in_channels, 64, kernel_size=1, stride=1, padding=0)#Shared Lateral Layer
        self.latlayer4 = nn.Conv2d(self.in_channels, 64, kernel_size=1, stride=1, padding=0)#Not Used


    def _make_layer(self, block, out_channels, num_blocks, stride):

        strides = [stride] + [1] * (num_blocks - 1)

        layers = []
        for stride in strides:
            layers.append(block(self.in_channels, out_channels, stride))
            self.in_channels = out_channels * block.expansion

        return nn.Sequential(*layers)


    def forward(self, x):

        # Bottom UP
        c1 = self.conv1(x)
        c2 = self.conv2_x(c1)
        c3 = self.conv3_x(c2)
        c4 = self.conv4_x(c3)
        c5 = self.conv5_x(c4)
        c6 = self.conv6_x(c5)


        # Top Down
        p5 = self.toplayer(c6)  # torch.Size([2, 256, 11, 11])

        p4 = torch.add(p5, self.latlayer1(c5))
        p3 = torch.add(p4, self.latlayer2(c4))
        p2 = torch.add(p3, self.latlayer3(c3))
        p1 = torch.add(p2, self.latlayer3(c2))

        # Smooth
        p44 = self.smooth1(p4)
        p33 = self.smooth2(p3)
        p22 = self.smooth3(p2)
        p11 = self.smooth4(p1)

        #Reconstruction Network
        x1 = p11 + p22 + p33 + p44
        x1 = torch.cat([x1, x], dim=1)
        x = self.pixel_shuffle(self.mainconv1(x1))

        return x

@register('srefpn')
def make_srefpn(in_channels, scale):
    args = Namespace()
    args.basicBlock = BasicBlock
    args.num_block = [2, 2, 2, 2, 2]
    args.in_channels = in_channels
    args.up_scale = scale   
    
    return SREFPN(args)
    
# def srefpn(in_channels, up_scale):
#     return SREFPN(BasicBlock, [2, 2, 2, 2, 2], in_channels, up_scale)