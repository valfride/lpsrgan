import torch
import torch.nn as nn

from argparse import Namespace
from models import register

class RDB_layer(nn.Module):
    def __init__(self, in_channels, grow_rate, k_size=3):
        super(RDB_layer, self).__init__()
        self.in_channels = in_channels
        self.grow_rate = grow_rate
        self.k_size = k_size
        
        self.conv=nn.Sequential(*[
            nn.Conv2d(self.in_channels, self.grow_rate, kernel_size=self.k_size, padding=(self.k_size-1)//2, stride=1),
            nn.ReLU()
            ])
        
        
        
    def forward(self, x):
        return torch.cat((x, self.conv(x)), dim=1)
        
class RDB(nn.Module):
    def __init__(self, init_grow_rate, grow_rate, n_conv, k_size):
        super(RDB, self).__init__()
        self.grow_init = init_grow_rate
        self.grow_rate = grow_rate
        self.n = n_conv
        
        convs = []
        
        for c in range(self.n):
            convs.append(RDB_layer(self.grow_init+c*self.grow_rate, self.grow_rate))
        
        self.convs=nn.Sequential(*convs)
        self.LFF = nn.Conv2d(self.grow_init+self.grow_rate*self.n, self.grow_init, kernel_size=1, padding=0, stride=1)
        
    def forward(self, x):
        return self.LFF(self.convs(x)) + x
        
class RDN(nn.Module):
    def __init__(self, args):
        super(RDN, self).__init__()
        self.args=args
        self.scale = args.scale
        
        self.kernel = args.kernel
        
        self.blocks, self.conv_layers, self.out_channels = {
            'A' : (20, 6, 32),
            'B' : (16, 8, 64),
            'C' : (20, 10, 128)
            }[args.RDNconfig]
        
        self.SFE1 = nn.Conv2d(args.in_channels, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        self.SFE2 = nn.Conv2d(args.init_grow_rate, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
        self.RDBs = nn.ModuleList()
        
        for i in range(self.blocks):
            self.RDBs.append(
                RDB(init_grow_rate=args.init_grow_rate, grow_rate=self.out_channels, n_conv=self.conv_layers, k_size=args.kernel),
                )
            
        self.GFF = nn.Sequential(*[
            nn.Conv2d(self.blocks*args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1),
            nn.Conv2d(args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1)
            ])
        
        self.UPNet = nn.Sequential(*[
                    nn.Conv2d(args.init_grow_rate, self.out_channels * self.scale * self.scale, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    nn.PixelShuffle(self.scale),
                    nn.Conv2d(self.out_channels, args.in_channels, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    # nn.Tanh()                
                ])
        
    def forward(self, x):
        f1 = self.SFE1(x)
        x = self.SFE2(f1)
        
        RDBs_out = []
        
        for i in range(self.blocks):
            x = self.RDBs[i](x)
            RDBs_out.append(x)
            
        x = self.GFF(torch.cat(RDBs_out,1))
        x += f1
        
        return self.UPNet(x)
        
        
@register('rdn')        
def make_rdn(init_grow_rate=64, kernel=3, scale=4, RDNconfig='C'):
    args = Namespace()
    args.init_grow_rate = init_grow_rate
    args.kernel = kernel
    args.RDNconfig = RDNconfig
    
    args.scale = scale
    args.in_channels = 3
    
    return RDN(args)

if __name__ == '__main__':
   model =  make_rdn()
   print(model)
   feature_maps = torch.rand(3, 3, 40, 20)
   print(model(feature_maps).shape)
