import math
import torch

from torch import nn as nn
from argparse import Namespace
from models import register

def make_layer(basic_block, num_basic_block, **kwarg):
    """Make layers by stacking the same blocks.

    Args:
        basic_block (nn.module): nn.module class for basic block.
        num_basic_block (int): number of blocks.

    Returns:
        nn.Sequential: Stacked blocks in nn.Sequential.
    """
    layers = []
    for _ in range(num_basic_block):
        layers.append(basic_block(**kwarg))
    return nn.Sequential(*layers)

class Upsample(nn.Sequential):
    """Upsample module.

    Args:
        scale (int): Scale factor. Supported scales: 2^n and 3.
        num_feat (int): Channel number of intermediate features.
    """

    def __init__(self, scale, num_feat):
        m = []
        if (scale & (scale - 1)) == 0:  # scale = 2^n
            for _ in range(int(math.log(scale, 2))):
                m.append(nn.Conv2d(num_feat, 4 * num_feat, 3, 1, 1))
                m.append(nn.PixelShuffle(2))
        elif scale == 3:
            m.append(nn.Conv2d(num_feat, 9 * num_feat, 3, 1, 1))
            m.append(nn.PixelShuffle(3))
        else:
            raise ValueError(f'scale {scale} is not supported. Supported scales: 2^n and 3.')
        super(Upsample, self).__init__(*m)


class ResidualBlockNoBN(nn.Module):
    """Residual block without BN.

    Args:
        num_feat (int): Channel number of intermediate features.
            Default: 64.
        res_scale (float): Residual scale. Default: 1.
        pytorch_init (bool): If set to True, use pytorch default init,
            otherwise, use default_init_weights. Default: False.
    """

    def __init__(self, num_feat=64, res_scale=1, pytorch_init=False):
        super(ResidualBlockNoBN, self).__init__()
        self.res_scale = res_scale
        self.conv1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=True)
        self.conv2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=True)
        self.relu = nn.ReLU(inplace=True)

        if not pytorch_init:
            default_init_weights([self.conv1, self.conv2], 0.1)

    def forward(self, x):
        identity = x
        out = self.conv2(self.relu(self.conv1(x)))
        return identity + out * self.res_scale


class EDSR(nn.Module):
    def __init__(self, args):
        super(EDSR, self).__init__()

        self.img_range = args.img_range
        self.mean = torch.Tensor(args.rgb_mean).view(1, 3, 1, 1)

        self.conv_first = nn.Conv2d(args.in_channels, args.num_feat, 3, 1, 1)
        self.body = make_layer(ResidualBlockNoBN, args.num_block, num_feat=args.num_feat, res_scale=args.res_scale, pytorch_init=True)
        self.conv_after_body = nn.Conv2d(args.num_feat, args.num_feat, 3, 1, 1)
        self.upsample = Upsample(args.upscale, args.num_feat)
        self.conv_last = nn.Conv2d(args.num_feat, args.out_channels, 3, 1, 1)

    def forward(self, x):
        self.mean = self.mean.type_as(x)

        x = (x - self.mean) * self.img_range
        x = self.conv_first(x)
        res = self.conv_after_body(self.body(x))
        res += x

        x = self.conv_last(self.upsample(res))
        x = x / self.img_range + self.mean

        return x

@register('EDSR')
def make_EDSR(in_channels, out_channels, num_feat=64, num_block=16, upscale=4, res_scale=1, img_range=255., rgb_mean=(0.4488, 0.4371, 0.4040)):
    """EDSR network structure.

    Paper: Enhanced Deep Residual Networks for Single Image Super-Resolution.
    Ref git repo: https://github.com/thstkdgus35/EDSR-PyTorch

    Args:
        num_in_ch (int): Channel number of inputs.
        num_out_ch (int): Channel number of outputs.
        num_feat (int): Channel number of intermediate features.
            Default: 64.
        num_block (int): Block number in the trunk network. Default: 16.
        upscale (int): Upsampling factor. Support 2^n and 3.
            Default: 4.
        res_scale (float): Used to scale the residual in residual block.
            Default: 1.
        img_range (float): Image range. Default: 255.
        rgb_mean (tuple[float]): Image mean in RGB orders.
            Default: (0.4488, 0.4371, 0.4040), calculated from DIV2K dataset.
    """

    args = Namespace()
    args.in_channels = in_channels
    args.out_channels = out_channels
    args.num_feat = num_feat
    args.num_block = num_block
    args.upscale = upscale
    args.res_scale = res_scale
    args.img_range = img_range
    args.rgb_mean = rgb_mean
     
    return EDSR(args)   

    
if __name__ == '__main__':
    input_data = torch.randn((16, 3, 20, 40))
    input_data2 = torch.randn((64, 3, 20, 40))
    model = make_EDSR(3, 3)
    print(model)
    print(model(input_data).shape)