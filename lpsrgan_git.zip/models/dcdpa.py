import torch
import torch.nn as nn

from argparse import Namespace
from models import register


class conv_relu_block(nn.Module):
    def __init__(self, in_channels, out_channels, kernel=3):
        super(conv_relu_block, self).__init__()
        self.kernel = kernel
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.layer = nn.Sequential(nn.Conv2d(in_channels=self.in_channels, out_channels=self.out_channels, kernel_size=self.kernel, stride=1, padding=(self.kernel-1)//2, bias=False),
                                   nn.ReLU())
        
    def forward(self, x):
        return self.layer(x)

class conv_bn_sig(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(conv_bn_sig, self).__init__()
        self.in_channels = in_channels
        self.out_channels = out_channels
        self.layer = nn.Sequential(
            nn.Conv2d(in_channels=self.in_channels, out_channels=self.out_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False),
            nn.BatchNorm2d(self.out_channels),
            nn.Sigmoid(),
            )
        
    def forward(self, x):
        return self.layer(x)

class ResidualNet(nn.Module):
    def __init__(self, channels, kernel=3, num_rb_layers=4):
        super(ResidualNet, self).__init__()
        self.kernel = kernel
        self.channels = channels
        
        self.in_conv = conv_relu_block(self.channels, self.channels)
        self.out_conv = conv_relu_block(self.channels, self.channels)
        self.residual_layers = self.make_layers(conv_relu_block, num_rb_layers)
        
    def make_layers(self, block, num_layers):
        layers = []
        
        for _ in range(num_layers):
            layers.append(block(self.channels, self.channels))
        return nn.Sequential(*layers)
    
    def forward(self, x):
        return torch.add(self.out_conv(self.residual_layers(self.in_conv(x))), x)
    
class DPDCA(nn.Module):
    def __init__(self, in_channels=64, out_channels=128):
        super(DPDCA, self).__init__()
        self.in_channels, self.out_channels = in_channels, out_channels
        self.conv5x5 = conv_relu_block(self.in_channels, self.in_channels, kernel=5)
        self.conv3x3 = conv_relu_block(self.in_channels, self.in_channels, kernel=3)
        
        self.conv_bn_sig1 = conv_bn_sig(self.in_channels, self.in_channels)
        self.conv_bn_sig2 = conv_bn_sig(self.in_channels, self.in_channels)
        self.conv_bn_sig3 = conv_bn_sig(self.in_channels, self.in_channels)
        self.conv_bn_sig4 = conv_bn_sig(self.in_channels, self.in_channels)
        
        self.p1 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p2 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p3 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p4 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p5 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p6 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p7 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        self.p8 = nn.Conv2d(self.in_channels, self.in_channels, kernel_size=1, stride=1, padding=(1-1)//2, bias=False)
        
        self.out_conv = nn.Sequential(
            nn.Conv2d(in_channels=4*self.in_channels, out_channels=self.out_channels, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
            nn.Sigmoid()
            )   
        
    def GAP(self, x, dim):
        return(torch.mean(x, dim=dim, keepdim=True))
    
    def forward(self, x):
        f3 = self.conv3x3(x)
        h3 = self.GAP(f3, 3).permute(0, 1, 3, 2)
        v3 = self.GAP(f3, 2)
        
        f5 = self.conv5x5(x)
        h5 = self.GAP(f5, 3).permute(0, 1, 3, 2)
        v5 = self.GAP(f5, 2)
        
        hv33 = self.conv_bn_sig1(torch.cat((h3, v3), dim=3))
        mat33 = self.p1(hv33[:, :, :, :f3.shape[3]])*f3*self.p2(hv33[:, :, :, f3.shape[3]:]).permute(0, 1, 3, 2)
        
        
        hv35 = self.conv_bn_sig2(torch.cat((h3, v5), dim=3))
        mat35 = self.p3(hv35[:, :, :, :f3.shape[3]])*f3*self.p4(hv35[:, :, :, f3.shape[3]:]).permute(0, 1, 3, 2)
        
        
        hv53 = self.conv_bn_sig3(torch.cat((h5, v3), dim=3))
        mat53 = self.p5(hv53[:, :, :, :f5.shape[3]])*f5*self.p6(hv53[:, :, :, f5.shape[3]:]).permute(0, 1, 3, 2)

        
        hv55 = self.conv_bn_sig4(torch.cat((h5, v5), dim=3))
        mat55 = self.p7(hv55[:, :, :, :f5.shape[3]])*f5*self.p8(hv55[:, :, :, f5.shape[3]:]).permute(0, 1, 3, 2)
        
        out = torch.cat((mat33, mat35, mat53, mat55), dim=1)
        
        return self.out_conv(out)
        
        
class CrossFusionBlock(nn.Module):
    def __init__(self, channels):
        super(CrossFusionBlock, self).__init__()
        
        self.channels = channels
        
        self.block1 = nn.Sequential(
            nn.Conv2d(in_channels=2*self.channels, out_channels=self.channels, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
            nn.Sigmoid()
            )
        
        self.block2 = nn.Sequential(
            nn.Conv2d(in_channels=2*self.channels, out_channels=self.channels, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
            nn.Sigmoid()
            )
        
    def forward(self, x1, x2):
        x = torch.cat((x1, x2), dim=1)
        se = self.block1(x)*x2+x1
        te = self.block1(x)*x1+x2
        
        return torch.cat((se, te), dim=1)
        

class GFB(nn.Module):
    def __init__(self, channels):
        super(GFB, self).__init__()
        
        self.channels = channels
        
        self.dpdca = DPDCA(self.channels, self.channels)
        self.cfb = CrossFusionBlock(self.channels)
        
    def forward(self, x, rgb, ldb):
        Matt = self.dpdca(rgb)
        NegMatt = (1-Matt)
        
        return self.cfb(Matt*rgb, NegMatt*ldb)
        
    
class PSTDNet(nn.Module):
    def __init__(self, args):
        super(PSTDNet, self).__init__()
        self.rgb_channels = args.rgb_channels
        self.gray_channels = args.gray_channels
        self.rb_hidden_channels = args.rb_hidden_channels
        self.num_layers = args.num_layers
        self.scale = args.scale
        
        
        self.rgb_rdn = nn.Conv2d(self.rgb_channels, self.rb_hidden_channels, kernel_size=5, stride=1, padding=(5-1)//2, bias=False)
        self.rgb_net = nn.ModuleList([ResidualNet(self.rb_hidden_channels) for _ in range(self.num_layers)])
        
        self.ldb_rdn = nn.Conv2d(self.gray_channels, self.rb_hidden_channels, kernel_size=5, stride=1, padding=(5-1)//2, bias=False)
        self.ldb_net = nn.ModuleList([ResidualNet(self.rb_hidden_channels) for _ in range(self.num_layers)])
        
        self.gfbs = nn.ModuleList([GFB(self.rb_hidden_channels) for _ in range(self.num_layers)])
        # self.gfb = nn.ModuleList([GFB(2*self.in_channels, 2*out_channels) for _ in range(num_layers)])
        
        self.dconv_dpca = nn.ConvTranspose2d(2*self.rb_hidden_channels, self.rb_hidden_channels, self.scale, stride=self.scale, bias=False)
        self.dconv_ldb = nn.ConvTranspose2d(self.rb_hidden_channels, self.rb_hidden_channels, self.scale, stride=self.scale, bias=False)
        
        self.out_convRGB = nn.Conv2d(2*self.rb_hidden_channels, 3, kernel_size=3, stride=1, padding=(3-1)//2, bias=False)
        self.out_convLBP = nn.Conv2d(self.rb_hidden_channels, 1, kernel_size=3, stride=1, padding=(3-1)//2, bias=False)
    def forward(self, x):
        x_rgb = self.rgb_rdn(x[0])
        x_ldb = self.ldb_rdn(x[1])
        
        dcdpa = torch.cat((x_rgb, x_ldb), dim=1)
        
        for i in range(self.num_layers):
            x_rgb = self.rgb_net[i](x_rgb)
            x_ldb = self.ldb_net[i](x_ldb)            
            dcdpa = self.gfbs[i](dcdpa, x_rgb, x_ldb)
        
        rgb = self.dconv_dpca(dcdpa)
        ldb = self.dconv_ldb(x_ldb)
        
        rgb = self.out_convRGB(torch.cat((rgb, ldb), dim=1))
        ldb = self.out_convLBP(ldb)
        # gfb, out_net1, out_net2 = torch.cat((out_sf, out_td), dim=1), self.net1[0](out_sf), self.net2[0](out_td)
        # gfb = self.gfb[0](gfb, out_net1, out_net2)
        
        return (rgb, ldb)

@register('PSTDNet')
def make_PSTDNet(rgb_channels=3, gray_channels=1, num_layers=4, scale=4, rb_hidden_channels=64):
    args = Namespace()
    args.rgb_channels = rgb_channels
    args.gray_channels = gray_channels
    args.num_layers = num_layers
    args.rb_hidden_channels = rb_hidden_channels
    args.scale = scale
    
    return PSTDNet(args)

if __name__ == '__main__':
   model =  make_PSTDNet()
   print(model)
   feature_maps = (torch.rand(1, 3, 40, 20), torch.rand(1, 1, 40, 20))
   print(model(feature_maps).shape)
        
        