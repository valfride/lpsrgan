import torch
import torch.nn as nn
import numpy as np

from argparse import Namespace
from models import register

class strLabelConverter(object):
    """Convert between str and label.

    NOTE:
        Insert `blank` to the alphabet for CTC.

    Args:
        alphabet (str): set of the possible characters.
        ignore_case (bool, default=True): whether or not to ignore all of the case.
    """

    def __init__(self, alphabet, ignore_case=False):
        self._ignore_case = ignore_case
        if self._ignore_case:
            alphabet = alphabet.lower()
        self.alphabet = '-'+alphabet  # for `-1` index

        self.dict = {}
        for i, char in enumerate(self.alphabet):
            # NOTE: 0 is reserved for 'blank' required by wrap_ctc
            self.dict[char] = i

    def encode(self, text):
        """Support batch or single str.

        Args:
            text (str or list of str): texts to convert.

        Returns:
            torch.IntTensor [length_0 + length_1 + ... length_{n - 1}]: encoded texts.
            torch.IntTensor [n]: length of each text.
        """

        length = []
        result = []
        decode_flag = True if type(text[0])==bytes else False

        for item in text:

            if decode_flag:
                item = item.decode('utf-8','strict')
            length.append(len(item))
            if len(item)<1:
                continue
            for char in item:
                index = self.dict[char]
                result.append(index)
        text = result
        return (torch.IntTensor(text), torch.IntTensor(length))

    def encode_char(self, char):

        return self.dict[char]
    
    def encode_list(self, text, K=8):
        """Support batch or single str.

        Args:
            text (str or list of str): texts to convert.
            K : the max length of texts

        Returns:
            torch.IntTensor [length_0 + length_1 + ... length_{n - 1}]: encoded texts.
            torch.IntTensor [n]: length of each text.
        """
        # print(text)
        length = []
        all_result = []
        decode_flag = True if type(text[0])==bytes else False

        for item in text:
            result = []
            if decode_flag:
                item = item.decode('utf-8','strict')
            # print(item)
            length.append(len(item))
            for i in range(K):
                # print(item)
                if i<len(item): 
                    char = item[i]
                    # print(char)
                    index = self.dict[char]
                    result.append(index)
                else:
                    result.append(0)
            all_result.append(result)
        return (torch.LongTensor(all_result))

    def decode(self, t, length, raw=False):
        """Decode encoded texts back into strs.

        Args:
            torch.IntTensor [length_0 + length_1 + ... length_{n - 1}]: encoded texts.
            torch.IntTensor [n]: length of each text.

        Raises:
            AssertionError: when the texts and its length does not match.

        Returns:
            text (str or list of str): texts to convert.
        """
        if length.numel() == 1:
            length = length[0]
            assert t.numel() == length, "text with length: {} does not match declared length: {}".format(t.numel(), length)
            if raw:
                return ''.join([self.alphabet[i - 1] for i in t])
            else:
                char_list = []
                for i in range(length):
                    if t[i] != 0 and (not (i > 0 and t[i - 1] == t[i])):
                        char_list.append(self.alphabet[t[i]])
                return ''.join(char_list)
        else:
            # batch mode
            assert t.numel() == length.sum(), "texts with length: {} does not match declared length: {}".format(t.numel(), length.sum())
            texts = []
            index = 0
            for i in range(length.numel()):
                l = length[i]
                texts.append(
                    self.decode(
                        t[index:index + l], torch.IntTensor([l]), raw=raw))
                index += l
            return texts
    
    def decode_list(self, t):
        texts = []
        for i in range(t.shape[0]):
            t_item = t[i,:]
            char_list = []
            for i in range(t_item.shape[0]):
                if t_item[i] == 0:
                    pass
                    # char_list.append('-')
                else:
                    char_list.append(self.alphabet[t_item[i]])
                # print(char_list, self.alphabet[44])
            # print('char_list:  ' ,''.join(char_list))
            texts.append(''.join(char_list))
        # print('texts:  ', texts)
        return texts

    def decode_sa(self, text_index):
        """ convert text-index into text-label. """
        texts = []
        for index, l in enumerate(text_index):
            text = ''.join([self.alphabet[i] for i in text_index[index, :]])
            texts.append(text.strip('-'))
        return texts

class SU(nn.Module):
    def __init__(self, channels):
        super(SU, self).__init__()
        self.SU = nn.Sequential(
            nn.ReLU(),
            nn.Conv3d(channels, channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.Sigmoid()
            )
        
    def forward(self, x):
        return x*self.SU(x)

class DWConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding='same', bias=False):
        super(DWConv2d, self).__init__()

        self.dConv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=1, groups=in_channels, padding=padding, bias=bias),
            nn.Conv2d(in_channels, out_channels, kernel_size=1)
            )
        
    def forward(self, x):
        x = self.dConv(x)
        
        return x

class RDB_layer(nn.Module):
    def __init__(self, in_channels, grow_rate, k_size=3):
        super(RDB_layer, self).__init__()
        self.in_channels = in_channels
        self.grow_rate = grow_rate
        self.k_size = k_size
        
        self.SU = SU(grow_rate)
        
        self.conv=nn.Sequential(*[
            nn.Conv3d(self.in_channels, self.grow_rate, kernel_size=self.k_size, padding=(self.k_size-1)//2, stride=1),
            self.SU
            # nn.ReLU()
            ])
        
        
        
    def forward(self, x):
        return torch.cat((x, self.conv(x)), dim=1)
    
class RDB(nn.Module):
    def __init__(self, init_grow_rate, grow_rate, n_conv, k_size):
        super(RDB, self).__init__()
        self.grow_init = init_grow_rate
        self.grow_rate = grow_rate
        self.n = n_conv
        convs = []
        
        for c in range(self.n):
            convs.append(RDB_layer(self.grow_init+c*self.grow_rate, self.grow_rate))
        
        self.convs=nn.Sequential(*convs)
        self.LFF = nn.Conv3d(self.grow_init+self.grow_rate*self.n, self.grow_init, kernel_size=1, padding=0, stride=1)
        
    def forward(self, x):        
        return self.LFF(self.convs(x))+x
    
class DenseLayer(nn.Module):
    def __init__(self, in_channels, out_channels, bias=False):
        super(DenseLayer, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding="same", bias=bias)
        self.ReLU = SU(out_channels)
        
        
    def forward(self, x):
        return torch.cat([x, self.ReLU(self.conv(x))], 1)    
    
class RDN(nn.Module):
    def __init__(self, args):
        super(RDN, self).__init__()
        self.args=args
        self.scale = args.scale
        self.depth_size = args.depth
        self.kernel = args.kernel
        self.conv_text = nn.Conv2d(1, 3, kernel_size=3, padding='same')
        self.embedding = nn.Embedding(36, 50)
        self.blocks, self.conv_layers, self.out_channels = {
            'A' : (20, 6, 32),
            'B' : (16, 8, 64),
            'C' : (20, 10, 128)
            }[args.RDNconfig]
        
        self.SFE1 = nn.Conv3d(self.depth_size, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        self.SFE2 = nn.Conv3d(args.init_grow_rate, args.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
        self.RDBs = nn.ModuleList()
        
        for i in range(self.blocks):
            self.RDBs.append(
                RDB(init_grow_rate=args.init_grow_rate, grow_rate=self.out_channels, n_conv=self.conv_layers, k_size=args.kernel),
                )
            
        self.GFF = nn.Sequential(*[
            nn.Conv3d(self.blocks*args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1),
            nn.Conv3d(args.init_grow_rate, args.init_grow_rate, kernel_size=1, padding=0, stride=1)
            ])
        self.outConv = nn.Conv3d(args.init_grow_rate, self.depth_size, self.kernel, padding='same')
        self.UPNet = nn.Sequential(*[
                    nn.Conv2d(self.depth_size*3, self.out_channels * self.scale * self.scale, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    nn.PixelShuffle(self.scale),
                    nn.Conv2d(self.out_channels, 3, self.kernel, padding=(self.kernel-1)//2, stride=1),
                    # nn.Tanh()                
                ])
        
    def forward(self, x, y):
        b, c, h, w = x.shape
        self.conv_text(y)
        x = x.view(b, self.depth_size, (c//self.depth_size), h, w)
        f1 = self.SFE1(x)
        x = self.SFE2(f1)
        
        RDBs_out = []
        
        for i in range(self.blocks):
            x = self.RDBs[i](x)
            RDBs_out.append(x)
            
        x = self.GFF(torch.cat(RDBs_out,1))
        x += f1
        x = self.outConv(x)
        x = x.view(b, c, h, w)
        
        return self.UPNet(x)

def compute_num_params(model, text=False):
    tot = int(sum([np.prod(p.shape) for p in model.parameters()]))
    if text:
        if tot >= 1e6:
            return '{:.1f}M'.format(tot / 1e6)
        else:
            return '{:.1f}K'.format(tot / 1e3)
    else:
        return tot    

@register('RDN3D')       
def RDN3D(in_channels=15, depth=5, scale=4, kernel=3, RDNconfig='B', init_grow_rate=128):
    args = Namespace()
    args.in_channels = in_channels
    args.depth = depth
    args.scale = scale
    args.kernel = kernel
    args.RDNconfig = RDNconfig
    args.init_grow_rate = init_grow_rate
    
    return RDN(args)

if __name__ == '__main__':
    # Assuming input data with shape (batch_size, depth, channels, height, width)
    input_data = torch.randn((16, 15, 20, 40))
    input_data2 = torch.randn((64, 32, 20, 40))
    text = 'ABC1234'
    converter = strLabelConverter('ABCDEFGHIJKLMNOPQRSTUVXYWZ123456789')
    text = converter.encode_list(text, K=8)
    # Net = RDN(num_channels=15, num_features=128, growth_rate=128, num_blocks=32, num_layers=3, bias=False)
    Net = RDN3D()
    
    print(Net)
    print(compute_num_params(Net, text=True))
    
    print("Output shape:", Net(input_data, text).shape)

        
        