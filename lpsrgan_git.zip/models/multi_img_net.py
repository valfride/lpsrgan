import torch
import torch.nn as nn
import torch.nn.functional as F

from argparse import Namespace
from models import register

import matplotlib.pyplot as plt
import numpy as np
import cv2
from tqdm import tqdm
from PIL import Image
from torchvision.ops import DeformConv2d

import torchvision.transforms as transforms
from . import cgnet_deformable2d_arch
from . import GP_LPR_arch

class DConv(nn.Module):
    def __init__(self, in_channels, out_channel, kernel_size, stride=1, padding='same', bias=True):
        super(DConv, self).__init__()

        self.dConv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=1, groups=in_channels, padding=padding, bias=bias),
            nn.Conv2d(in_channels, out_channel, kernel_size=1)
            )
        
    def forward(self, x):
        x = self.dConv(x)
        
        return x

class SelfAttention(nn.Module):
    def __init__(self, embed_dim, num_heads):
        super().__init__()
        self.embed_dim = embed_dim
        self.num_heads = num_heads
        self.head_dim = embed_dim // num_heads

        assert self.head_dim * num_heads == embed_dim, "Embedding dimension must be divisible by number of heads"

        # Linear layers for queries, keys, and values
        self.query = nn.Linear(embed_dim, embed_dim)
        self.key = nn.Linear(embed_dim, embed_dim)
        self.value = nn.Linear(embed_dim, embed_dim)

        # Output linear layer
        self.out = nn.Linear(embed_dim, embed_dim)

    def forward(self, x):
        # x shape: (batch, num_patches, embed_dim)
        batch_size, num_patches, embed_dim = x.shape

        # Linear transformations for queries, keys, and values
        Q = self.query(x)  # Shape: (batch, num_patches, embed_dim)
        K = self.key(x)    # Shape: (batch, num_patches, embed_dim)
        V = self.value(x)  # Shape: (batch, num_patches, embed_dim)

        # Reshape for multi-head attention
        Q = Q.view(batch_size, num_patches, self.num_heads, self.head_dim).transpose(1, 2)  # (batch, num_heads, num_patches, head_dim)
        K = K.view(batch_size, num_patches, self.num_heads, self.head_dim).transpose(1, 2)  # (batch, num_heads, num_patches, head_dim)
        V = V.view(batch_size, num_patches, self.num_heads, self.head_dim).transpose(1, 2)  # (batch, num_heads, num_patches, head_dim)

        # Scaled dot-product attention
        scale = self.head_dim ** -0.5
        attention_scores = (Q @ K.transpose(-2, -1)) * scale  # (batch, num_heads, num_patches, num_patches)
        attention_weights = F.softmax(attention_scores, dim=-1)  # (batch, num_heads, num_patches, num_patches)

        # Apply attention to values
        out = attention_weights @ V  # (batch, num_heads, num_patches, head_dim)
        out = out.transpose(1, 2).contiguous().view(batch_size, num_patches, embed_dim)  # (batch, num_patches, embed_dim)

        # Output linear layer
        out = self.out(out)  # (batch, num_patches, embed_dim)

        return out

def visualize_patch_group(patch_group, group_idx):
    """
    Visualize a specific patch group.
    
    Args:
        patch_group: Tensor of shape (batch, num_images, channels, height, patch_width).
        group_idx: Index of the patch group (for labeling).
    """
    batch_size, num_images, channels, height, patch_width = patch_group.shape

    # Create a grid to display patches for each image
    fig, axes = plt.subplots(batch_size, num_images, figsize=(10, batch_size * 2))

    for b in range(batch_size):
        for img_idx in range(num_images):
            # Select the patch for the current batch and image
            patch = patch_group[b, img_idx]

            # Ensure the patch has 3 dimensions (channels, height, width)
            if patch.dim() == 2:
                patch = patch.unsqueeze(0)  # Add a channel dimension if missing

            # Display the patch
            axes[b, img_idx].imshow(patch.permute(1, 2, 0).squeeze(), cmap='gray')
            axes[b, img_idx].axis('off')
            axes[b, img_idx].set_title(f"Batch {b + 1}, Image {img_idx + 1}")

    plt.suptitle(f"Patch Group {group_idx + 1}", y=1.02)
    plt.tight_layout()
    plt.show()

def visualize_patches(patches, batch_idx, space_width=2):
    """
    Visualize patches for a specific batch (license plate) as a grid.
    
    Args:
        patches: Tensor of shape (batch, num_images, channels, num_patches, height, patch_width).
        batch_idx: Index of the batch (license plate) to visualize.
        space_width: Width of the horizontal space between patches (in pixels).
    """
    # Select patches for the specified batch
    patches_batch = patches[batch_idx]  # Shape: (num_images, channels, num_patches, height, patch_width)

    num_images, channels, num_patches, height, patch_width = patches_batch.shape

    # Create a grid to display patches for each image
    fig, axes = plt.subplots(num_images, 1, figsize=(10, num_images * 2))

    for img_idx in range(num_images):
        # Initialize an empty tensor to hold the concatenated patches with spaces
        patch_row = torch.zeros((channels, height, num_patches * patch_width + (num_patches - 1) * space_width))

        # Insert patches with horizontal space
        start = 0
        for p in range(num_patches):
            end = start + patch_width
            patch_row[:, :, start:end] = patches_batch[img_idx, :, p]
            start = end + space_width  # Add space after each patch

        # Ensure the patch row has 3 dimensions (channels, height, width)
        if patch_row.dim() == 2:
            patch_row = patch_row.unsqueeze(0)  # Add a channel dimension if missing

        # Display the patch row
        axes[img_idx].imshow(patch_row.permute(1, 2, 0).squeeze(), cmap='gray')
        axes[img_idx].axis('off')
        axes[img_idx].set_title(f"Image {img_idx + 1}")

    plt.tight_layout()
    plt.show()

class PatchFeatureExtractor(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride, padding, in_images=5):
        super().__init__()
        self.block1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size, stride, padding="same"),
            nn.PixelShuffle(2),
            nn.ReLU(),
            nn.Conv2d(int(out_channels*(1/2)**2), out_channels, 3, stride, padding="same"),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(out_channels, out_channels, 3, stride, padding="same"),
            nn.BatchNorm2d(out_channels),
            nn.ReLU(),
            nn.Conv2d(out_channels, out_channels, 3, stride, padding="same"),
            nn.BatchNorm2d(out_channels),
            nn.ReLU() 
            
        )
        
    def forward(self, x):
        # x shape: (batch, num_images, channels, height, patch_width)
        batch_size, num_images, channels, height, patch_width = x.shape

        # Reshape x to combine batch and num_images dimensions
        x = x.view(batch_size * num_images, channels, height, patch_width)

        # Apply Conv2d
        x = self.block1(x)  # Shape: (batch * num_images, out_channels, new_height, new_width)

        # # Reshape back to separate batch and num_images dimensions
        x = x.view(batch_size, num_images, x.shape[1], x.shape[2], x.shape[3])

        return x
    
class TemporalFusion(nn.Module):
    def __init__(self, channels=64, num_heads=8):
        super().__init__()
        self.transformer = nn.TransformerEncoderLayer(
            d_model=channels,
            nhead=num_heads,
            dim_feedforward=256,
            batch_first=True
        )
        
    def forward(self, x):
        # x: (batch, 5, channels, H, W)
        batch, T, C, H, W = x.shape
        x = x.reshape(batch, T, C*H*W)  # Flatten spatial dimensions
        x = self.transformer(x)          # (batch, 5, C*H*W)
        x = x.reshape(batch, T, C, H, W)
        return x.mean(dim=1)  # Average over time → (batch, C, H, W)

class Align(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.offset_net = nn.Conv2d(channels*2, 18, kernel_size=3, padding=1)  # 2*3x3 kernels
        self.deform_conv = DeformConv2d(channels, channels, kernel_size=3, padding=1)

    def forward(self, ref_frame, target_frame):
        batch_size, num_images, channels, height, patch_width = ref_frame.shape
        ref_frame = ref_frame.view(batch_size*num_images, channels, height, patch_width)
        target_frame = target_frame.view(batch_size*num_images, channels, height, patch_width)
        
        offset = self.offset_net(torch.cat([ref_frame, target_frame], dim=1))
        aligned = self.deform_conv(target_frame, offset)
        
        aligned = aligned.view(batch_size, num_images, channels, height, patch_width)
        
        
        return aligned

class TemporalNetwork(nn.Module):
    def __init__(self, args):
        super(TemporalNetwork, self).__init__()
        self.patch_size = (16, 4)
        self.num_patches = 48//4
        self.embed_dim = 64
        
        self.pos_embed = nn.Parameter(torch.randn(self.num_patches, 32))
        
        self.feature_extractors = nn.ModuleList([
            PatchFeatureExtractor(args.in_channels, 32, kernel_size=7, stride=1, padding="same")
            for _ in range(self.num_patches)
        ])
        
        self.pos_embed = nn.Parameter(torch.randn(self.num_patches, 32))
        
        self.TemporalFusion = nn.ModuleList([
            TemporalFusion(32*self.patch_size[0]*self.patch_size[1], 4)
            for _ in range(self.num_patches)
        ])
        # self.upsample_module = 
        self.align = Align(32)
        
        self.attention = nn.MultiheadAttention(self.embed_dim, 32)
        self.out_counv =  nn.Sequential(
            DConv(32, 32, kernel_size=3),
            nn.PixelShuffle(2),
            nn.ReLU(),
            nn.Conv2d(int(32*(1/2)**2), 32, 3, stride=1, padding="same")
            )
        
        # DConv(32, 32, kernel_size=3)
    
    def images_to_patches(self, images, patch_size):
        """
        Divide a batch of sequential images into patches.
        
        Args:
            images: Input tensor of shape (batch, num_images, channels, height, width).
            patch_size: Tuple (patch_height, patch_width) specifying the size of each patch.
            
        Returns:
            patches: Tensor of shape (batch, num_images, channels, num_patches, patch_height, patch_width).
        """
        batch_size, num_images, channels, height, width = images.shape
        patch_height, patch_width = patch_size
    
        # Unfold the images into patches
        patches = images.unfold(3, patch_height, patch_height).unfold(4, patch_width, patch_width)
    
        # Reshape and permute the tensor
        patches = patches.contiguous().view(batch_size, num_images,  channels, -1, patch_height, patch_width)

        return patches
    
    def group_patches_by_index(self, patches):
        """
        Group patches by their index across all batches and images.
        
        Args:
            patches: Tensor of shape (batch, num_images, channels, num_patches, height, patch_width).
            
        Returns:
            patch_groups: List of tensors, where each tensor corresponds to a specific patch index.
                         Each tensor has shape (batch, num_images, channels, height, patch_width).
        """
        # Get the number of patches
        num_patches = patches.shape[3]
    
        # Permute and reshape the tensor to group patches by their index
        patches = patches.permute(3, 0, 1, 2, 4, 5)  # Shape: (num_patches, batch, num_images, channels, height, patch_width)
    
        # Split the tensor into a list of tensors, one for each patch index
        patch_groups = [patches[p] for p in range(num_patches)]
    
        return patch_groups        
            
    def forward(self, x):
        # aligned_images = 
        
        patches = self.images_to_patches(x, self.patch_size)
    
        patch_groups = self.group_patches_by_index(patches)
        
        # Extract features for each patch group
        feature_groups = [self.feature_extractors[i](patch_group) for i, patch_group in enumerate(patch_groups)]
        feature_groups = [feature_group + self.pos_embed[i].view(1, -1, 1, 1) for i, feature_group in enumerate(feature_groups)]
        
        p_size = len(feature_groups)
        aligned_features = [feature_groups[p_size//2]]
        for t in range(1, p_size):
            aligned = self.align(aligned_features[0], feature_groups[t])  # Align frame t to frame 0
            aligned_features.append(aligned)
        
        feature_temporal_group = [self.TemporalFusion[i](aligned_feature) for i, aligned_feature in enumerate(aligned_features)]

        output = self.out_counv(torch.cat(feature_temporal_group, dim=3))
        return output
    
class SR_LPR_NET(nn.Module):
    def __init__(self, in_channels=64, out_channels=3):
        super(SR_LPR_NET, self).__init__()
        
        # Define the arguments
        args = Namespace()
        args.in_channels = in_channels
        args.out_channels = out_channels
        
        # Define the networks
        self.temporal_network = TemporalNetwork(args)
        self.ocr = GP_LPR_arch.make_GPLPR(nc=32)
        self.lcdnet = cgnet_deformable2d_arch.cgnet(32, 3)
    
    def forward(self, x):
        # Pass input through the TemporalNetwork
        temporal_output = self.temporal_network(x)
        
        # Pass the output to both OCR and lcdnet
        _, preds,_ = self.ocr(F.interpolate(temporal_output, (32, 96), mode='bicubic'))
        # F.interpolate(temporal_output, (32, 96), mode='bicubic')
        lcdnet_output = self.lcdnet(temporal_output)
        
        # Return the outputs from both networks
        return preds, lcdnet_output
    
    

@register('multi_img_net_test')        
def make(in_channels=64, out_channels=3):
    return SR_LPR_NET(in_channels, out_channels)

if __name__ == '__main__':
    input_data2 = torch.randn((64, 3, 32, 96))
    
    
    model = SR_LPR_NET(3, 7)
    atten_list, text_preds, enc_slf_attn = model(input_data2)
    print(model)
    print(f"{text_preds.shape}")
