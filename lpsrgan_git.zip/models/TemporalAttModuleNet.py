import torch
import torch.nn as nn
import numpy as np

from argparse import Namespace
from models import register

class SU(nn.Module):
    def __init__(self, channels):
        super(SU, self).__init__()
        self.SU = nn.Sequential(
            nn.ReLU(),
            nn.Conv3d(channels, channels, kernel_size=1, stride=1, padding=0, bias=False),
            nn.Sigmoid()
            )
        
    def forward(self, x):
        return x*self.SU(x)

class DWConv2d(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size, stride=1, padding='same', bias=False):
        super(DWConv2d, self).__init__()

        self.dConv = nn.Sequential(
            nn.Conv2d(in_channels, in_channels, kernel_size, stride=1, groups=in_channels, padding=padding, bias=bias),
            nn.Conv2d(in_channels, out_channels, kernel_size=1)
            )
        
    def forward(self, x):
        x = self.dConv(x)
        
        return x

class RDB_layer(nn.Module):
    def __init__(self, in_channels, grow_rate, k_size=3):
        super(RDB_layer, self).__init__()
        self.in_channels = in_channels
        self.grow_rate = grow_rate
        self.k_size = k_size
        
        self.SU = SU(grow_rate)
        
        self.conv=nn.Sequential(*[
            nn.Conv3d(self.in_channels, self.grow_rate, kernel_size=self.k_size, padding=(self.k_size-1)//2, stride=1),
            self.SU
            # nn.ReLU()
            ])
        
        
        
    def forward(self, x):
        return torch.cat((x, self.conv(x)), dim=1)
    
class RDB(nn.Module):
    def __init__(self, init_grow_rate, grow_rate, n_conv, k_size):
        super(RDB, self).__init__()
        self.grow_init = init_grow_rate
        self.grow_rate = grow_rate
        self.n = n_conv
        convs = []
        
        for c in range(self.n):
            convs.append(RDB_layer(self.grow_init+c*self.grow_rate, self.grow_rate))
        
        self.convs=nn.Sequential(*convs)
        self.LFF = nn.Conv3d(self.grow_init+self.grow_rate*self.n, self.grow_init, kernel_size=1, padding=0, stride=1)
        
    def forward(self, x):        
        return self.LFF(self.convs(x))+x
    
class DenseLayer(nn.Module):
    def __init__(self, in_channels, out_channels, bias=False):
        super(DenseLayer, self).__init__()
        self.conv = nn.Conv3d(in_channels, out_channels, kernel_size=3, padding="same", bias=bias)
        self.ReLU = SU(out_channels)
        
        
    def forward(self, x):
        return torch.cat([x, self.ReLU(self.conv(x))], 1)    
    

class RDN3D(nn.Module):
    def __init__(self, in_channels,  kernel, grow_rate=128, config='B'):
        super(RDN3D, self).__init__()
        self.kernel = kernel
        self.init_grow_rate = grow_rate
        self.config = 'D'
        self.blocks, self.conv_layers, self.out_channels = {
            'A' : (20, 6, 32),
            'B' : (16, 8, 64),
            'C' : (20, 10, 128),
            'D' : (3, 3, 32)
            }[self.config]
        
        self.SFE1 = nn.Conv3d(in_channels, self.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        self.SFE2 = nn.Conv3d(self.init_grow_rate, self.init_grow_rate, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
        self.RDBs = nn.ModuleList()
        
        for i in range(self.blocks):
            self.RDBs.append(
                RDB(init_grow_rate=self.init_grow_rate, grow_rate=self.out_channels, n_conv=self.conv_layers, k_size=self.kernel),
                )
            
        self.GFF = nn.Sequential(*[
            nn.Conv3d(self.blocks*self.init_grow_rate, self.init_grow_rate, kernel_size=1, padding='same', stride=1),
            nn.Conv3d(self.init_grow_rate, self.init_grow_rate, kernel_size=1, padding='same', stride=1)
            ])
        
        self.out_channels = nn.Conv3d(self.init_grow_rate, self.out_channels, self.kernel, padding=(self.kernel-1)//2, stride=1)
        
    def forward(self, x):
        f1 = self.SFE1(x)
        x = self.SFE2(f1)
        
        RDBs_out = []
        
        for i in range(self.blocks):
            x = self.RDBs[i](x)
            RDBs_out.append(x)
            
        x = self.GFF(torch.cat(RDBs_out,1))
        x += f1
        
        return self.out_channels(x)


class TAttModule(nn.Module):
    def __init__(self, args):
        super(TAttModule, self).__init__()
        self.in_channels = args.in_channels
        self.growth = args.growth
        self.kernel = 3
        self.num_images = args.num_images
        
        self.temporal_convs = []
        self.sfs = []
        
        for i in range((self.num_images//2)):
            self.sfs.append(
                nn.Conv3d(3, self.growth, 7, padding="same", stride=1, bias=False).cuda()
                )
            
            self.temporal_convs.append(
                nn.Sequential(nn.Conv3d(3, 32, self.kernel, padding="same", stride=1, bias=False),
                                             nn.BatchNorm3d(32),
                                             nn.ReLU(),
                                             nn.Conv3d(32, self.growth, 1, padding="same", stride=1, bias=False)).cuda()
                )
        
        # self.sf1 = nn.Conv3d(3, self.growth, 7, padding="same", stride=1, bias=False)
        # self.sf2 = nn.Conv3d(3, self.growth, 7, padding="same", stride=1, bias=False)
        # self.conv3D1 = nn.Sequential(nn.Conv3d(3, 32, self.kernel, padding="same", stride=1, bias=False),
        #                              nn.BatchNorm3d(32),
        #                              nn.ReLU(),
        #                              nn.Conv3d(32, self.growth, 1, padding="same", stride=1, bias=False)
        #     )
        # self.conv3D2 = nn.Sequential(nn.Conv3d(3, 32, self.kernel, padding="same", stride=1, dilation=1, bias=False),
        #                              nn.BatchNorm3d(32),
        #                              nn.ReLU(),
        #                              nn.Conv3d(32, self.growth, 1, padding="same", stride=1, bias=False)
        #     )
        
        self.rdn3d = RDN3D(self.growth*(self.num_images//2), 3)
        self.out_conv = nn.Conv2d(32*3, self.in_channels, kernel_size=3, stride=1, padding='same', bias=False)
        
    
    def temporal_grouping(self, x, num_images=5):
        """
        Organizes a tensor of concatenated images into sets of stacked images with a reference image.
    
        Args:
        - concat_tensor (Tensor): Concatenated tensor of images with shape (1, C*H, W).
        - reference_index (int): Index of the reference image in the concatenated tensor.
        - num_images_side (int): Number of images to stack with the reference image on each side.
    
        Returns:
        - sets_stacked (list): List of sets of stacked images.
        """
        index_ref = ((x.shape[1]//2)-1)
        reference_image = x[:, index_ref:index_ref+3, :, :]
        
        sets_stacked = []
        prev_index = next_index = index_ref
        for i in range(num_images//2):
            prev_index = prev_index-3
            next_index = next_index+3
            
            stacked_set = torch.cat([x[:, prev_index:(prev_index+3), :, :],
                                 reference_image,
                                 x[:, next_index:(next_index+3), :, :]], dim=1)
            sets_stacked.append(stacked_set)
        return sets_stacked
            
    
    def forward(self, x):
        b, c, h, w = x.shape
        stacks = self.temporal_grouping(x, self.num_images)
        features = []
        for i in range(len(stacks)):
            xi = stacks[i].view(b, 3, 3, h, w)
            features.append(self.temporal_convs[i](xi)*self.sfs[i](xi))
            
        features = torch.cat((features), dim=1)
        # x0 = stacks[0].view(b, 3, 3, h, w)
        # features0 = self.conv3D1(x0)*x0
        # x1 = stacks[1].view(b, 3, 3, h, w)
        # features1 = self.conv3D2(x1)*x1
        out = self.rdn3d(features)
        out = self.out_conv(out.view(b, out.shape[1]*out.shape[2], h, w))

        return x*out

def NET(in_channels=15, growth=64, num_images=5):
    args = Namespace()
    args.in_channels = in_channels
    args.growth = growth
    args.num_images = num_images
   
    
    return TAttModule(args)

if __name__ == '__main__':
    # Assuming input data with shape (batch_size, depth, channels, height, width)
    input_data = torch.randn((16, 15, 20, 40))
    input_data2 = torch.randn((64, 32, 20, 40))
    model = NET()
    print(model(input_data).shape)