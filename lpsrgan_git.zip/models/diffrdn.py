import torch
import torch.nn as nn
import torch.nn.functional as F

from argparse import Namespace
from models import register


class Unet_block(nn.Module):
    def __init__(self, in_channels, hidden_channels, stride=1):
        super(Unet_block, self).__init__()
        self.in_channels, self.hidden_channels = in_channels, hidden_channels
        self.kernel=3
        self.block = nn.Sequential(
            nn.Conv2d(self.in_channels, self.hidden_channels, kernel_size=self.kernel, stride=stride, padding=(self.kernel-1)//2, bias=False),
            nn.BatchNorm2d(self.hidden_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(self.hidden_channels, self.hidden_channels, kernel_size=self.kernel, stride=stride,  padding=(self.kernel-1)//2, bias=False),
            nn.BatchNorm2d(self.hidden_channels),
            )
        
        if stride != 1 or in_channels != hidden_channels:
            self.shortcut = nn.Sequential(
                nn.Conv2d(in_channels, hidden_channels, kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(hidden_channels)
            )
        else:
            self.shortcut = nn.Identity()
        
    def forward(self, x):
        return self.block(x) + self.shortcut(x)
 
class UNet_row_up(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1):
        super(UNet_row_up, self).__init__()
        self.in_channels, self.out_channels = in_channels, out_channels
        self.kernel=3
        self.block = nn.Sequential(
            nn.BatchNorm2d(self.in_channels),
            nn.Conv2d(self.in_channels, self.out_channels, kernel_size=self.kernel, stride=stride, padding=(self.kernel-1)//2, bias=False),
            nn.ReLU(inplace=True),
            nn.Conv2d(self.out_channels, self.out_channels*2**2, kernel_size=self.kernel, stride=stride,  padding=(self.kernel-1)//2, bias=False),
            nn.PixelShuffle(2)
            )
        
    def forward(self, x):
        return self.block(x)       
   
class UNet_row_down(nn.Module):
    def __init__(self, in_channels, hidden_channels, num_blocks):
        super(UNet_row_down, self).__init__()
        self.in_channels, self.hidden_channels, self.num_blocks = in_channels, hidden_channels, num_blocks
        self.row = []
        
        for i in range(self.num_blocks):
            self.row.append(Unet_block(self.in_channels, self.hidden_channels))
            
        self.row = nn.Sequential(*self.row)
        self.MaxPool = nn.MaxPool2d(kernel_size=2, stride=2)
        
        
    def forward(self, x):
        return self.MaxPool(self.row(x))
    

    
class UNet(nn.Module):
    def __init__(self, args):
        super(UNet, self).__init__()
        self.in_conv = nn.Sequential(nn.Conv2d(args.in_channels, 64, kernel_size=7, stride=1, padding=(7-1)//2, bias=False),
                                     nn.BatchNorm2d(64),
                                     nn.ReLU())
        self.out_conv = nn.Sequential(nn.Conv2d(160, 64, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
                                     nn.ReLU(),
                                     nn.Conv2d(64, 64, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
                                     nn.ReLU(),
                                     nn.Conv2d(64, args.out_channels, kernel_size=3, stride=1, padding=(3-1)//2, bias=False),
                                     # nn.Sigmoid()
                                     )
        
        self.row_down1 = nn.Sequential(UNet_row_down( 64,  64, 3), Unet_block(64, 128))
        self.row_down2 = nn.Sequential(UNet_row_down(128, 128, 3), Unet_block(128, 256))
        self.row_down3 = nn.Sequential(UNet_row_down(256, 256, 6), Unet_block(256, 512))
        self.row_down4 = nn.Sequential(UNet_row_down(512, 512, 2), Unet_block(512, 1024),
                                       nn.BatchNorm2d(1024),
                                       nn.ReLU())
        
        self.mid_row = nn.Sequential(nn.Conv2d(1024, 512, kernel_size=3, stride=1, padding=1, bias=False),
                      nn.ReLU(),
                      nn.Conv2d(512, 512, kernel_size=3, stride=1, padding=1, bias=False),
                      nn.ReLU())
        
        self.row_up1 = UNet_row_up(384, 96)
        self.row_up2 = UNet_row_up(640, 256)
        self.row_up3 = UNet_row_up(1024, 384)
        self.row_up4 = UNet_row_up(1536, 512)   

    def forward(self, x):
        _, _, h, w = x.size()
        if h % 16 != 0:
           x = nn.functional.pad(x, (0, 0, 0, 16 - h % 16))  # Add padding to make height divisible by 4
        if w % 16 != 0:
           x = nn.functional.pad(x, (0, 16 - w % 16, 0, 0))  # Add padding to make width divisible by 4
        
        x0 = self.in_conv(x)
        
        x1 = self.row_down1(x0)
        x2 = self.row_down2(x1)
        x3 = self.row_down3(x2)
        x4 = self.row_down4(x3)
        
        x5 = self.mid_row(x4)
        
        x6 = self.row_up4(torch.cat((x4, x5), dim=1))
        x7 = self.row_up3(torch.cat((x3, x6), dim=1))
        x8 = self.row_up2(torch.cat((x2, x7), dim=1))
        x9 = self.row_up1(torch.cat((x1, x8), dim=1))
        
        out = self.out_conv(torch.cat((x0, x9), dim=1))
        
        padded_h, padded_w = out.size()[2:]

        # Calculate the amount of padding added
        pad_h = padded_h - h
        pad_w = padded_w - w
        
        # Crop the image to remove the padding
        out = out[:, :, pad_h//2:pad_h//2+h, pad_w//2:pad_w//2+w]
        
        return out


@register('UNet')        
def make_UNet(in_channels=64, out_channels=3):
    args = Namespace()
    args.in_channels = in_channels
    args.out_channels = out_channels

    
    return UNet(args)

if __name__ == '__main__':
   model =  make_UNet()
   print(model)
   feature_maps = torch.rand(3, 64, 41, 20)
   print(model(feature_maps).shape)
