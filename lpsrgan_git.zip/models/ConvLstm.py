import torch
import torch.nn as nn
import torch.nn.functional as F

class ConvLSTMCell(nn.Module):
    def __init__(self, in_channels, hidden_channels, kernel_size, bias=True):
        super(ConvLSTMCell, self).__init__()
        
        self.in_channels = in_channels
        self.hidden_channels = hidden_channels
        self.kernel_size = kernel_size
        self.padding = kernel_size // 2
        self.bias = bias
        
        # Defined gates: forget, input, cell state, output
        self.Wxi = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whi = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxf = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whf = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxc = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Whc = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
        self.Wxo = nn.Conv2d(in_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        self.Who = nn.Conv2d(hidden_channels, hidden_channels, kernel_size, padding=self.padding, bias=bias)
        
    def forward(self, x, h, C):
        i = torch.sigmoid(self.Wxi(x) + self.Whi(h))
        f = torch.sigmoid(self.Wxf(x) + self.Whf(h))
        g = torch.tanh(self.Wxc(x) + self.Whc(h))
        o = torch.sigmoid(self.Wxo(x) + self.Who(h))
        
        C = f * C + i * g
        h = o * torch.tanh(C)
        
        return h, C
    
class ConvLSTMLayer(nn.Module):
    def __init__(self, input_channels, hidden_channels, kernel_size, num_layers, bidirectional=True, batch_first=False, squeeze_outputs=True):
        super(ConvLSTMLayer, self).__init__()
        self.hidden_channels = hidden_channels
        self.num_layers = num_layers
        self.batch_first = batch_first
        self.squeeze = squeeze_outputs
        self.bidirectional = bidirectional
        self.num_directions = 2 if bidirectional else 1

        # Create a list of ConvLSTM cells for each layer
        self.cells_forward = nn.ModuleList([
            ConvLSTMCell(input_channels if i == 0 else hidden_channels * self.num_directions, hidden_channels, kernel_size)
            for i in range(num_layers)
        ])
        
        if bidirectional:
            self.cells_backward = nn.ModuleList([
                ConvLSTMCell(input_channels if i == 0 else hidden_channels * self.num_directions, hidden_channels, kernel_size)
                for i in range(num_layers)
            ])
   
    def _init_hidden(self, batch_size, height, width):
        h_0 = [torch.zeros(batch_size, self.hidden_channels, height, width).to(next(self.parameters()).device)
               for _ in range(self.num_layers * self.num_directions)]
        C_0 = [torch.zeros(batch_size, self.hidden_channels, height, width).to(next(self.parameters()).device)
               for _ in range(self.num_layers * self.num_directions)]
        return h_0, C_0
   
    def forward(self, x, hidden=None):
        if self.batch_first:
            batch_size, seq_len, num_channels, height, width = x.size()
        else:
            seq_len, batch_size, num_channels, height, width = x.size()
        
        if hidden is None:
            h_0, C_0 = self._init_hidden(batch_size, height, width)
        else:
            h_0, C_0 = hidden
        
        outputs = []
        h_n, C_n = [], []
        
        for layer in range(self.num_layers):
            h_t_f, C_t_f = h_0[layer], C_0[layer]
            output_seq_forward = []
            
            if self.bidirectional:
                h_t_b, C_t_b = h_0[layer + self.num_layers], C_0[layer + self.num_layers]
                output_seq_backward = []
            
            for t in range(seq_len):
                x_t = x[:, t, :, :, :] if self.batch_first else x[t, :, :, :, :]
                h_t_f, C_t_f = self.cells_forward[layer](x_t, h_t_f, C_t_f)
                output_seq_forward.append(h_t_f)
                
                if self.bidirectional:
                    x_t_b = x[:, -t-1, :, :, :] if self.batch_first else x[-t-1, :, :, :, :]
                    h_t_b, C_t_b = self.cells_backward[layer](x_t_b, h_t_b, C_t_b)
                    output_seq_backward.insert(0, h_t_b)
        
            if self.bidirectional:
                 x_f = torch.stack(output_seq_forward, dim=1 if self.batch_first else 0)
                 x_b = torch.stack(output_seq_backward, dim=1 if self.batch_first else 0)
                 x = torch.cat((x_f, x_b), dim=2)
            else:
                x = torch.stack(output_seq_forward, dim=1 if self.batch_first else 0)

            outputs.append(x)
            h_n.append(h_t_f)
            C_n.append(C_t_f)
        
            
            if self.bidirectional:
                h_n.append(h_t_b)
                C_n.append(C_t_b)

        outputs = torch.stack(outputs, dim=0)
        h_n = torch.stack(h_n, dim=0)
        C_n = torch.stack(C_n, dim=0)
        
        return outputs, h_n, C_n

    
if __name__ == '__main__':
    feature_maps = torch.rand(3, 3, 16, 48)
    image = feature_maps.unsqueeze(2)
    print(image.shape)
    # image = image.permute(0, 2, 1, 3, 4)
    # print(image.shape)
    lstm = ConvLSTMLayer(input_channels=1, hidden_channels=32, kernel_size=3, num_layers=3, batch_first=True, bidirectional=True)
    print(lstm)
    outputs, h, c = lstm(image)
    outputs = outputs.squeeze(2)

    print(image.shape)
    print(f"H:{h.shape}\nC:{c.shape}\nO:{outputs.shape}")